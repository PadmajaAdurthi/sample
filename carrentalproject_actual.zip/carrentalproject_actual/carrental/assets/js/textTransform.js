$(document).ready(function () {
    $('#headerText').addClass('writer');
});