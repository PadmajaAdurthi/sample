<?php
session_start();
error_reporting(0);
include('includes/config.php');
if (strlen($_SESSION['alogin']) == 0) {
	header('location:index.php');
} else {
	?>
	<!doctype html>
	<html lang="en" class="no-js">

	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<meta name="theme-color" content="#3e454c">

		<title>KOPAs Sales and Services | Admin Dashboard</title>

		<!-- Font awesome -->
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- Sandstone Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Bootstrap Datatables -->
		<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
		<!-- Bootstrap social button library -->
		<link rel="stylesheet" href="css/bootstrap-social.css">
		<!-- Bootstrap select -->
		<link rel="stylesheet" href="css/select.css">
		<!-- Bootstrap file input -->
		<link rel="stylesheet" href="css/fileinput.min.css">
		<!-- Awesome Bootstrap checkbox -->
		<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
		<!-- Admin Stye -->
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>
		<?php include('includes/header.php'); ?>

		<div class="ts-main-content">
			<?php include('includes/leftbar.php'); ?>
			<div class="content-wrapper">
				<div class="gray-bg field-title text-center">
					<h3>Dashboard</h3>
				</div>
				<div class="inlineDisplay dashColStyle">
					<div class="divCar">
						<div class="stat-panel text-center cartop bk-warning">
							<?php
								$sql = "SELECT id from tblusers ";
								$query = $dbh->prepare($sql);
								$query->execute();
								$results = $query->fetchAll(PDO::FETCH_OBJ);
								$regusers = $query->rowCount();
								?>
							<!-- <div class="stat-panel-number h1 "></div> -->
							<div class="stat-panel-title text-uppercase carText">Total Users: <?php echo htmlentities($regusers); ?>

							</div>

						</div>
						<div class="bottom bk-warning carText">
							<a href="reg-users.php">Full Detail <i class="fa fa-arrow-right"></i></a>
						</div>
						<div class="fwheel"></div>
						<div class="bwheel"></div>
					</div>
					<div class=" divCar">
						<div class="stat-panel text-center cartop bk-danger">
							<?php
								$sql1 = "SELECT id from tblvehicles ";
								$query1 = $dbh->prepare($sql1);;
								$query1->execute();
								$results1 = $query1->fetchAll(PDO::FETCH_OBJ);
								$totalvehicle = $query1->rowCount();
								?>

							<div class="stat-panel-title text-uppercase carText">Total Vehicles: <?php echo htmlentities($totalvehicle); ?></div>
						</div>
						<div class="bottom bk-danger carText">
							<a href="manage-vehicles.php">Full Detail &nbsp; <i class=" fa fa-arrow-right"></i></a>
						</div>
						<div class="fwheel"></div>
						<div class="bwheel"></div>
					</div>

				</div>
				<div class="inlineDisplay dashColStyle">
					<div class="divCar">
						<div class="stat-panel text-center cartop bk-success">
							<?php
								$sql2 = "SELECT id from tblservice ";
								$query2 = $dbh->prepare($sql2);
								$query2->execute();
								$results2 = $query2->fetchAll(PDO::FETCH_OBJ);
								$bookings = $query2->rowCount();
								?>

							<!-- <div class="stat-panel-number h1 "></div> -->
							<div class="stat-panel-title text-uppercase carText">Total Services: <?php echo htmlentities($bookings); ?></div>
						</div>
						<div class="bottom bk-success carText">
							<a href="manage-services.php">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
						</div>
						<div class="fwheel"></div>
						<div class="bwheel"></div>
					</div>
					<div class=" divCar">
						<div class="stat-panel text-center cartop bk-green">
							<?php
								$sql3 = "SELECT id from tblbrands ";
								$query3 = $dbh->prepare($sql3);
								$query3->execute();
								$results3 = $query3->fetchAll(PDO::FETCH_OBJ);
								$brands = $query3->rowCount();
								?>
							<!-- <div class="stat-panel-number h1 "></div> -->
							<div class="stat-panel-title text-uppercase carText">Total Brands: <?php echo htmlentities($brands); ?></div>
						</div>
						<div class="bottom bk-green carText">
							<a href="manage-brands.php">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
						</div>
						<div class="fwheel"></div>
						<div class="bwheel"></div>
					</div>

				</div>
				<div class="inlineDisplay dashColStyle">
					<div class=" divCar">
						<div class="stat-panel text-center cartop bk-info">
							<?php
								$sql3 = "SELECT BookingId from vehiclebooking ";
								$query3 = $dbh->prepare($sql3);
								$query3->execute();
								$results3 = $query3->fetchAll(PDO::FETCH_OBJ);
								$booking = $query3->rowCount();
								?>
							<!-- <div class="stat-panel-number h1 "></div> -->
							<div class="stat-panel-title text-uppercase carText">Total Bookings: <?php echo htmlentities($booking); ?></div>
						</div>
						<div class="bottom bk-info carText">
							<a href="manage-vehicle-booking.php">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
						</div>
						<div class="fwheel"></div>
						<div class="bwheel"></div>
					</div>
					<div class="divCar">
						<div class="stat-panel text-center cartop bk-blue">
							<?php
								$sql3 = "SELECT partId from tblpart ";
								$query3 = $dbh->prepare($sql3);
								$query3->execute();
								$results3 = $query3->fetchAll(PDO::FETCH_OBJ);
								$parts = $query3->rowCount();
								?>
							<!-- <div class="stat-panel-number h1 "></div> -->
							<div class="stat-panel-title text-uppercase carText">Total Parts: <?php echo htmlentities($parts); ?></div>
						</div>
						<div class="bottom bk-blue carText">
							<a href="manage-parts.php">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
						</div>
						<div class="fwheel"></div>
						<div class="bwheel"></div>
					</div>

				</div>

			</div>
			<?php include('includes/footer.php'); ?>
			<!-- Loading Scripts -->
			<script src="js/jquery.min.js"></script>
			<script src="js/main.js"></script>


	</body>

	</html>
<?php } ?>