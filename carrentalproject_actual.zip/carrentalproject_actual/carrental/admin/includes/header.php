<div class="brand clearfix">
	<div id="headerText" class="inlineDisplay headerMargin">
		<span class="textappear ">KOPA Sales and Services</span>
	</div>


	<ul class="ts-profile-nav">
		<li class="ts-account">
			<a href="#">Account <i class="fa fa-angle-down hidden-side"></i></a>
			<ul>
				<li><a href="change-password.php">Change Password</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</li>
	</ul>
</div>