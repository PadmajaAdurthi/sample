<footer>
  <div class="footer-bottom">
  </div>
</footer>