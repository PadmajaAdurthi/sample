	<nav class="ts-sidebar">
		<ul class="ts-sidebar-menu">
			<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>

			<li><a href="manage-brands.php"><i class="fa fa-star"></i> Manage Brand</a>
			</li>

			<li><a href="#"><i class="fa fa-car"></i>Vehicles</a>
				<ul>
					<li><a href="manage-vehicles.php">Manage Vehicle</a></li>
					<li><a href="manage-vehicle-booking.php">Manage Vehicle Booking</a></li>
				</ul>
			</li>
			<li><a href="manage-services.php"><i class="fa fa-wrench"></i> Manage Service</a></li>
			<li><a href="manage-parts.php"><i class="fa fa-puzzle-piece"></i> Manage Parts</a></li>
			<li><a href="reg-users.php"><i class="fa fa-users"></i> Manage Users</a></li>


		</ul>
	</nav>